

#ifndef UTILES_DEFINICIONES_H
#define UTILES_DEFINICIONES_H

#include <iostream>
#include <vector>
#include <tuple>
#include <cmath>

using namespace std;

// DEFINICIONES DE TIPO
typedef  vector<int> senial;
typedef  vector<tuple<int,int> > ventanas;
typedef  vector<float> promedios;


#endif //UTILES_DEFINICIONES_H
