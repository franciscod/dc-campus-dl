#include "auxiliares.h"

vector<int> ordenado(vector<int> s){
  // COMPLETAR
    vector<int> res;
    return res;
}

void ordenar(vector<int>& s){
  // COMPLETAR
}

vector<int> range(int desde_inclusive, int hasta_inclusive){
    // COMPLETAR

    vector<int> res;
    return res;
}

vector<int> concatenar(vector<int> s, vector<int> t){
    // COMPLETAR

    vector<int> res;
    return res;
}


