#include "auxiliares.h"
#include "ejercicios.h"


bool esValida(senial s){
  // Completar
  return 0;
}

float media(senial s){
    // Completar
    return 0;
}

vector<int> ctrlf(senial s, int x){
    // Completar
    vector<int> res;
    return res;
}

int maximo(senial s, int& latencia){
    // Completar
    return 0;
}

int medianaEntera(senial s, int& latencia){
    // Completar
    return 0;
}

tuple<vector<int>,vector<float> > histograma(senial s, int bins){
  // Completar
    tuple<vector<int>,vector<float> > res;
    return res;
}

float distanciaEuclidiana(senial p, senial q){
    // Completar
    return 0;
}

tuple<promedios,ventanas > slidingWindows(senial s, vector<int> tamanios){
    // Completar
    tuple<promedios,ventanas > res;
    return res;
}

void completar(senial& s, vector<int> missings){
    // Completar
}

vector<int> sacarOutliers(senial& s){
    // Completar
    vector<int> res;
    return res;
}

tuple<float,vector<tuple<int,int> > > distanciaAcordeon(senial s, senial q){
    // Completar (OPCIONAL)
    tuple<float,vector<tuple<int,int> > > res;
    return res;
}
