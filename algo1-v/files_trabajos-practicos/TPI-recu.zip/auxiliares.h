//
// Created by pbrusco on 22/05/18.
//
#include "definiciones.h"

using namespace std;

#ifndef LECTURADECEREBROS_AUXILIARES_H
#define LECTURADECEREBROS_AUXILIARES_H

vector<int> ordenado(vector<int> s);
void ordenar(vector<int>& s);
vector<int> range(int desde_inclusive, int hasta_inclusive);
vector<int> concatenar(vector<int> s, vector<int> t);

#endif //LECTURADECEREBROS_AUXILIARES_H
