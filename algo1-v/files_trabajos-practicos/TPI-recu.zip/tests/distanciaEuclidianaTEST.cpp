#include "../ejercicios.h"
#include "gtest/gtest.h"

using namespace std;

TEST(distanciaEuclidianaTEST, todosNegativos){
    senial p = {-67, -47, -361};
    senial q = {-58, -184, -214};
    EXPECT_NEAR(distanciaEuclidiana(p,q), 201.144,0.001);
}

TEST(distanciaEuclidianaTEST, todosPositivos){
    senial p = {67, 47, 361};
    senial q = {58, 184, 214};
    EXPECT_NEAR(distanciaEuclidiana(p,q), 201.144,0.001);
}

TEST(distanciaEuclidianaTEST, resultadoCero){
    senial p = {67, 47, 361};
    senial q = {67, 47, 361};
    EXPECT_NEAR(distanciaEuclidiana(p,q), 0,0.00001);
}

TEST(distanciaEuclidianaTEST, pMayorAQ){
    senial p = {67, 47, 361};
    senial q = {-58, -184, -214};
    EXPECT_NEAR(distanciaEuclidiana(p,q), 632.147,0.001);
}

TEST(distanciaEuclidianaTEST, qMayorAP){
    senial p = {-58, -184, -214};
    senial q = {67, 47, 361};
    EXPECT_NEAR(distanciaEuclidiana(p,q), 632.147,0.001);
}

TEST(distanciaEuclidianaTEST, mezclados){
    senial p = {6, -21, 15};
    senial q = {-14, 31, -8};
    EXPECT_NEAR(distanciaEuclidiana(p,q), 60.274,0.001);
}