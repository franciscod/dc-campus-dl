#include "../ejercicios.h"
#include "gtest/gtest.h"

using namespace std;

TEST(mediaTEST, resultadoEntero){
    senial s = {124, -25, -250, 17};
    EXPECT_NEAR(media(s),-33.5,0.001);
}

TEST(mediaTEST, resultadoNoEntero){
    senial s = {-529, 361, 22, 0, 781};
    EXPECT_NEAR(media(s),127,0.001);
}

TEST(mediaTEST, senialNegativa){
    senial s = {-351, -247, -1268, -999, -59};
    EXPECT_NEAR(media(s),-584.8,0.001);
}