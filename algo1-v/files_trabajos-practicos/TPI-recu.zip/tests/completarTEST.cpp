#include "../ejercicios.h"
#include "gtest/gtest.h"

using namespace std;



void testeo (vector<int> &s, vector<int> &res) {
    ASSERT_EQ(s.size(), res.size());
    for (int i = 0; i < s.size(); ++i) {
        EXPECT_EQ(s[i], res[i]);
    }
}
TEST(completarTEST, huecoSimple){
    vector<int> missings = {2};

    senial s = {33,25,0,3,1};
    senial res = {33,25,14,3,1};

    completar(s,missings);

    testeo (s,res);
}

TEST(completarTEST, huecoDoble){
    vector<int> missings = {2,3};

    senial s = {33,25,0,0,3,1};
    senial res = {33,25,14,14,3,1};

    completar(s,missings);

    testeo (s,res);
}
TEST(completarTEST, huecoTriple){
    vector<int> missings = {2,3,4};

    senial s = {33,25,0,0,0,3,1};
    senial res = {33,25,14,14,14,3,1};

    completar(s,missings);

    testeo (s,res);
}
TEST(completarTEST, dobleHueco){
    vector<int> missings = {2,3,5};

    senial s = {33,25,0,0,3,0,1};
    senial res = {33,25,14,14,3,2,1};

    completar(s,missings);

    testeo (s,res);
}

TEST(completarTEST, huecoAlComienzo){
    vector<int> missings = {1,4,5,7};

    senial s = {3,0,2,25,0,0,3,0,1};
    senial res = {3,3,2,25,14,14,3,2,1};

    completar(s,missings);

    testeo (s,res);
}

TEST(completarTEST, missingDesordenados){
    vector<int> missings = {7,5,1,4};

    senial s = {3,0,2,25,0,0,3,0,1};
    senial res = {3,3,2,25,14,14,3,2,1};

    completar(s,missings);

    testeo (s,res);
}