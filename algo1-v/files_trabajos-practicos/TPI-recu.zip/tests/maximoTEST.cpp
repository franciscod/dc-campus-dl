#include "../ejercicios.h"
#include "gtest/gtest.h"

using namespace std;

TEST(maximoTEST, todosNegativos){
    senial s = {-578, -984, -214};
    int latencia;
    int max = maximo(s,latencia);
    EXPECT_EQ(max, -214);
    EXPECT_EQ(latencia, 2);
}

TEST(maximoTEST, todosPositivos){
    senial s = {78, 746, 156};
    int latencia;
    int max = maximo(s,latencia);
    EXPECT_EQ(max, 746);
    EXPECT_EQ(latencia, 1);
}

TEST(maximoTEST, maximoCero){
    senial s = {0, -85, -1570};
    int latencia;
    int max = maximo(s,latencia);
    EXPECT_EQ(max, 0);
    EXPECT_EQ(latencia, 0);
}