#include "../ejercicios.h"
#include "gtest/gtest.h"
#include "../auxiliares.h"

using namespace std;




void testeo (vector<int> &s, vector<int> &res, vector<int> &borrados, vector<int> &borradosRes) {
    ASSERT_EQ(s.size(), res.size());
    for (int i = 0; i < s.size(); ++i)
        EXPECT_EQ(s[i], res[i]);

    ASSERT_EQ(ordenado(borrados), ordenado(borradosRes));


}

TEST(sacarOutliersTEST, sacoUno){
    senial s = range(0, 20);
    senial res = s;
    res[20] = 0;

    vector<int> borradosRes = {20};
    vector<int> borrados = sacarOutliers(s);

    testeo (s,res, borrados, borradosRes);
}


TEST(sacarOutliersTEST, sacoVariosJuntos){
    senial s = range(0, 100);
    senial res = s;
    res[100] = 0;
    res[99] = 0;
    res[98] = 0;
    res[97] = 0;
    res[96] = 0;

    vector<int> borradosRes = {100, 99, 98, 97, 96};
    vector<int> borrados = sacarOutliers(s);

    testeo (s,res, borrados, borradosRes);
}

TEST(sacarOutliersTEST, sacoVariosSeparados){
    senial s = concatenar(range(1, 50), range(1, 50));
    senial res = s;
    res[49] = 0;
    res[48] = 0;
    res[98] = 0;
    res[99] = 0;

    vector<int> borradosRes = {48, 49, 98, 99};
    vector<int> borrados = sacarOutliers(s);

    testeo (s,res, borrados, borradosRes);
}

TEST(sacarOutliersTEST, noSacoNinguno){ //todos iguales no saca ninguno
    senial s = {33,33,33,33};
    senial res = {33,33,33,33};

    vector<int> borradosRes = {};
    vector<int> borrados = sacarOutliers(s);

    testeo (s,res, borrados, borradosRes);
}

TEST(sacarOutliersTEST, noSacoNingunoDistintos){
    senial s = {1,2,3,4};
    senial res = s;

    vector<int> borradosRes = {};
    vector<int> borrados = sacarOutliers(s);

    testeo (s,res, borrados, borradosRes);
}
