#include "auxiliares.h"
#include "ejercicios.h"


bool esValida(senial s){
  // Completar
  return 0;
}

float media(senial s){
    // Completar
    return 0;
}

vector<int> ctrlf(senial s, int x){
    // Completar
    vector<int> res;
    return res;
}

int maximo(senial s, int& latencia){
    // Completar
    return 0;
}

int medianaEntera(senial s, int& latencia){
    // Completar
    return 0;
}

tuple<vector<int>,vector<float> > histograma(senial s, int bins){
  // Completar
    tuple<vector<int>,vector<float> > res;
    return res;
}

float distanciaEuclidiana(senial p, senial q){
    // Completar
    return 0;
}

tuple<promedios,ventanas > slidingWindows(senial s, vector<int> tamanios){
    // Completar
    tuple<promedios,ventanas > res;
    return res;
}

void completar(senial& s, vector<int> missings){
    // Completar
}

vector<int> sacarOutliers(senial& s){
    // Completar
    vector<int> res;
    return res;
}

vector<tuple<int, int>> mejorCamino(vector< vector<float>> DTW){
    vector<tuple<int, int>> camino;
    int i = DTW.size() - 1;
    int j = DTW[0].size() - 1;
    float current_min;
    while(i != 0 && j != 0){
        camino.push_back(make_tuple(i-1, j-1));

        current_min = min(min(DTW[i - 1][j], DTW[i][j - 1]), DTW[i - 1][j - 1]);
        if(current_min == DTW[i-1][j]){
            i = i-1;
        }else if(current_min == DTW[i][j-1]){
            j = j-1;
        }else{
            i = i-1;
            j = j-1;
        }

    }
    return camino;
};


float distanciaCamino(vector<tuple<int, int>> camino, senial s, senial q){
    float cuenta = 0;
    for (int k = 0; k < camino.size(); ++k) {
        tuple<int, int> par = camino[k];
        int i = get<0>(par);
        int j = get<1>(par);
        cuenta += pow(s[i] - q[j], 2);
    }
    return sqrt(cuenta);
}


tuple<float, vector<tuple<int, int> > > distanciaAcordeon(senial s, senial q){
    int n = s.size();
    int m = q.size();
    float costo;
    float min_dist;

    vector< vector<float>> DTW = vector<vector<float>>(n+1, vector<float>(m+1));
    for (int i = 0; i < n+1; ++i) {
        DTW[i][0] = MAXFLOAT;
    }
    for (int j = 0; j < m+1; ++j) {
        DTW[0][j] = MAXFLOAT;
    }

    DTW[0][0] = 0;
    for (int i = 1; i < n+1; ++i) {
        for (int j = 1; j < m+1; ++j) {
            costo = abs(s[i-1] - q[j-1]);
            min_dist = min(min(DTW[i-1][j], DTW[i][j-1]), DTW[i-1][j-1]);
            DTW[i][j] = costo + min_dist;
        }
    }

    vector<tuple<int, int>> camino = mejorCamino(DTW);

    float res = distanciaCamino(camino, s, q);
    return make_tuple(res, camino);
};
