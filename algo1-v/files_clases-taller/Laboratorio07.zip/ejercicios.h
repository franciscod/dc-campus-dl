#ifndef LABORATORIO07_EJERCICIOS_H
#define LABORATORIO07_EJERCICIOS_H

#include <vector>
#include <string>

using namespace std;

typedef vector<vector<int> > matriz;
typedef vector<vector<int> > tablero;

void imprimir(matriz m);
void transponer(matriz m);
int picos(matriz m);

string tateti(tablero t);
bool hayAmenaza(tablero t);
bool sePuedenUbicarReinas(int n);


#endif //LABORATORIO07_EJERCICIOS_H
