#include "ejercicios.h"


void imprimir(matriz m){

};

void transponer(matriz m){

};

int picos(matriz m){
    return 0;
};

string tateti(tablero t){
    return "hola";
};

bool hayAmenaza(tablero t){
    return false;
};

bool sePuedenUbicarReinas(int n){
    return false;
};

