#include <iostream>
#include "ejercicios.h"

int main() {

    matriz a ={{15,2,32}, {4,1,6}, {7,14,15}};
    imprimir(a);

    transponer(a);
    imprimir(a);

    cout << "picos de la matriz: " << picos(a) << endl;

    cout << tateti({{' ', ' ', ' '}, {' ', ' ', ' '}, {' ', ' ', ' '}}) << endl;
    cout << tateti({{' ', ' ', ' '}, {' ', 'x', ' '}, {' ', ' ', ' '}}) << endl;;
    cout << tateti({{' ', ' ', ' '}, {' ', 'x', ' '}, {' ', ' ', 'c'}}) << endl;;
    cout << tateti({{' ', 'x', ' '}, {' ', 'x', ' '}, {' ', ' ', 'c'}}) << endl;;
    cout << tateti({{' ', 'x', 'c'}, {'x', 'c', 'x'}, {'c', 'x', 'c'}}) << endl;;


    cout << hayAmenaza({{' ', 'r', ' '}, {' ', ' ', ' '}, {'r', ' ', ' '}}) << endl;
    cout << hayAmenaza({{' ', ' ', ' '}, {' ', 'r', ' '}, {'r', ' ', ' '}}) << endl;

    cout << sePuedenUbicarReinas(8) << endl;

    return 0;
}