#include <iostream>
#include <vector>
#include <utility>
#include <math.h>
using namespace std;

int indiceMinSubsec(vector<int> v, int i, int j);
int sumarElementos(vector<int> s);
int mcd(int m, int n);
pair<int, int> division(int n, int d);
void fibonaccizar(vector<int>& s);
bool existePico(vector<int> s);
void ordenar1(vector<int>& v);
void ordenar2(vector<int>& v);

void mostrarVector(vector<int> v);

