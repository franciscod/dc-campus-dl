#include "ejercicios.h"


int indiceMinSubsec(vector<int> v, int i, int j){
    cout << "Implementame!" << endl;
    return 0;
}

int sumarElementos(vector<int> s){
    cout << "Implementame!" << endl;
    return 0;
}

int mcd(int m, int n){
    cout << "Implementame!" << endl;
    return 0;
}

pair<int, int> division(int n, int d){
    cout << "Implementame!" << endl;
    return pair<int, int>();
}

void fibonaccizar(vector<int>& s){
    cout << "Implementame!" << endl;
}

bool existePico(vector<int> s){
    cout << "Implementame!" << endl;
    return false;
}

void ordenar1(vector<int>& v){
    cout << "Implementame!" << endl;
}

void ordenar2(vector<int>& v){
    cout << "Implementame!" << endl;
}



void mostrarVector(vector<int> v){

    std::cout << "[";
    for(int i = 0; i < v.size()-1; i++){
        std::cout << v[i] << ", ";
    }
    if(v.size() > 0)
        std::cout << v[v.size()-1];

    std::cout << "]" << std::endl;
}
