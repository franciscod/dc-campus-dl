#include <iostream>
#include <vector>
#include <utility>
#include <math.h>
#include "ejercicios.h"

using namespace std;


int main() {

    std::cout << "probar!" << std::endl;

    return 0;
}

