#include <string>
#include <iostream>

using namespace std;

string indice_substring_corregido(string s, char delim, int ind) {
	bool encontre = false;
	int i = 0;
	int actual = 0;
	string res;
	while(i < s.size() && !encontre) {
		if(s[i] != delim)
			while(i<s.size() && s[i] != delim){
				res.push_back(s[i]);
				i++;
			}
		if (ind==actual){
			encontre = true;
		} else {
			res.clear();
			i++;
			actual++;
		}
	}
	if (encontre || ind == actual)
		return res;
	else
		return "Indice fuera de rango";
}

string indice_substring(string s, char delim, int ind) {
    bool encontre = false;
    int i = 0;
    int actual = 0;
    string res;
    while(i < s.size() && !encontre) {
        if(s[i] != delim)
            while(i<s.size() && s[i] != delim){
                res.push_back(s[i]);}
                i++;

        if (ind==actual){
            encontre = true;
        } else {
            res.clear();
            actual++;
        }
    }
    if (encontre || ind == actual)
        return res;
    else
        return "Indice fuera de rango";
}


int cant_apariciones(string s, char c){
	int count = 0;
	for (int i=0; i<s.size(); i++){
		if(s[i]==c)
			count++;
	}
	return count;
}

int main() {
	string s = "hola#que#tal#como#estas";
	for (int i=0; i<cant_apariciones(s,'#')+1; i++)
		cout << "i=" << i << "  " << indice_substring(s,'#', i) << endl;
}