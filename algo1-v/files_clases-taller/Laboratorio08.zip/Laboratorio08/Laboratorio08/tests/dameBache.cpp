#include "../src/ejercicios.h"
#include "gtest/gtest.h"

using namespace std;


TEST(dameBacheTest, ordenados){
    vector<int> s={1,2,4};
    ASSERT_EQ(3, dameBache(s));
}

TEST(dameBacheTest, desordenados1){
    vector<int> s={3,-1,1,0};
    ASSERT_EQ(2, dameBache(s));
}

TEST(dameBacheTest, desordenados2){
    vector<int> s={-5,-2,-3};
    ASSERT_EQ(-4, dameBache(s));
}

TEST(dameBacheTest, desordenados3){
    vector<int> s={-6, -5,-4,-2,-3, 0};
    ASSERT_EQ(-1, dameBache(s));
}
