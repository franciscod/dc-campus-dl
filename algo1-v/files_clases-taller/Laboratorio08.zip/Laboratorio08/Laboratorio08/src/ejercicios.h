#include <iostream>
#include <string>
#include <vector>
#include "math.h"

using namespace std;

bool contieneElementos(vector<int>& a, vector<int>& b);
vector<int> naipesFaltantes(vector<int>& naipes);
int dameBache(vector<int>& s);
int dameBache1(vector<int>& s);
bool perteneceRotadas(vector<int>& s, int elem);


