#include "ejercicios.h"



bool contieneElementos(vector<int>& a, vector<int>& b){
    cout << "Implementame" << endl;

    return false;
}


vector<int> naipesFaltantes(vector<int>& naipes){
    cout << "Implementame" << endl;

    vector<int> naipesFaltantes;
    return naipesFaltantes;
}


int dameBache(vector<int>& s){
    cout << "Implementame" << endl;
    return 0;

}

int dameBache1(vector<int>& s){
    cout << "Implementame" << endl;
    return 0;

}

bool perteneceRotadas(vector<int>& s, int elem) {

    cout << "Implementame" << endl;

    return false;
}

