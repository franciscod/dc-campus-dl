#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <fstream>


using namespace std;



void selectionSort(vector<int> &items){
    cout << "Implementame" << endl;
}



void countingSort(vector<int> &items) {
    cout << "Implementame" << endl;

}

void ordenar(vector<int> &items){
    selectionSort(items);
    //countingSort(items);
}


int bestFit(int W, vector<int> &items){
    multiset<int> restos;
    for(int i=0; i<(int)items.size(); ++i){
        restos.insert(W);
    }
    int res = 0;
    for(int i=0; i<(int)items.size(); ++i){
        multiset<int>::iterator it = restos.lower_bound(items[i]);
        int restoAct = *it;
        if(restoAct==W){
            res++;
        }
        restoAct -= items[i];
        restos.erase(it);
        restos.insert(restoAct);
    }
    return res;
}

int tomarDatos(string nombreArchivo, vector<int>& items, int& volumen){
    fstream archivoDeEntrada;
    archivoDeEntrada.open(nombreArchivo.c_str());
    bool res = true;
    int cantidadItems = 0;
    if(archivoDeEntrada.is_open()){
        string var;
        archivoDeEntrada >> cantidadItems;
        archivoDeEntrada >> volumen;

        while( archivoDeEntrada >> var ) {
            items.push_back(atoi(var.c_str()));
        }
        archivoDeEntrada.close();
    }else{
        res = false;
    }


    return res;
}


int main(){

    cout << "Ingrese el nombre de archivo que contiene los datos. Ejemplo: ../archivos/BPP.txt \n";
    string nombreArchivo;
    cin >> nombreArchivo;

    vector<int> items;
    int W = 0;
    bool abrioArchivo;
    abrioArchivo = tomarDatos(nombreArchivo, items, W);
    if(!abrioArchivo){
        cout << "No se pudo abrir el archivo." << endl;
    }else{
        //Se corre best-fit
        int cant1 = bestFit(W, items);
        cout << "Con la idea bestFit, se consigue una asignacion con " << cant1 << " contenedores" << endl;

        //Se ordenan los items
        ordenar(items);
        //Se corre best-fit-decreasing
        int cant2 = bestFit(W, items);
        cout << "Con la idea bestFitDecreasing, se consigue una asignacion con " << cant2 << " contenedores" << endl;
    }

    return 0;
}
