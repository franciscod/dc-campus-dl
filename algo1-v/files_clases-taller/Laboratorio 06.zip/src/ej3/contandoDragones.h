int contandoDragones(int T, int d1, int d2, int d3);
