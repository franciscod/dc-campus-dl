#include "../../src/ej2/puntaje.h"
#include "../../lib/gtest/gtest.h"

// Escribir tests aca:
