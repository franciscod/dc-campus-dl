bool sandia(int peso) {
	return true;
	// Borrar el return dummy y completar
}
