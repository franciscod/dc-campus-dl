int contandoDragones(int T, int d1, int d2, int d3) {
	return 0;
	// Borrar el return dummy y completar
}
