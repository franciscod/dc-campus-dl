bool sandia(int peso);
