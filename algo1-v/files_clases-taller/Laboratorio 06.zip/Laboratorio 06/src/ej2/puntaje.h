int puntaje(int b);
