void llenarTaxis1(int g1, int g2, int g3, int& res);
void llenarTaxis2(int g1, int g2, int g3, int& res);
void llenarTaxis3(int g1, int g2, int g3, int& res);
