#include "../../src/ej3/baldosasDelPiso.h"
#include "../../lib/gtest/gtest.h"

// Escribir tests aca:
