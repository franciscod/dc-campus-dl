#include <iostream>
#include "ejercicios.cpp"


int main() {
    std::cout << "A probar se ha dicho!" << std::endl;
    vector<int> v;
    v.push_back(-20);
    v.push_back(30);
    v.push_back(40);
    vector<int> v2 = v;
    v2.push_back(3);

    std::cout << divide(v, 10) << std::endl;
    std::cout << divide(v2, 10) << std::endl;
    std::cout << maximo(v2) << std::endl;
    mostrarVector(v2);
    std::cout << endl;

    // COMPLETAR CON MAS PRUEBAS

    return 0;
}
