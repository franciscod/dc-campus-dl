#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <stdlib.h>

using namespace std;

// vectores + recursion
bool divide(vector<int> v, int n);
bool divideRec(vector<int> v, int n);

int maximo(vector<int> v);
int maximoRec(vector<int> v);

bool pertenece(int elem, vector<int> v);
bool perteneceRec(int elem, vector<int> v);

// vectores
vector<int> rotar(vector<int> v, int k);
vector<int> reverso(vector<int> v);
vector<int> factoresPrimos(int n);
void mostrarVector(vector<int> v);
bool estaOrdenado(vector<int> v);


// integradores
void negadorDeBooleanos(vector<bool> &booleanos);
void palindromos(string rutaArchivoIn, string rutaArchivoOut);
void promedios(string rutaArchivoIn1, string rutaArchivoIn2, string rutaArchivoOut);
void cantidadApariciones(string rutaArchivo, string rutaArchivoOut);
int cantidadAparicionesDePalabra(string rutaArchivo, string palabra);
void estadisticas(string rutaArchivo);
void intersecion();
