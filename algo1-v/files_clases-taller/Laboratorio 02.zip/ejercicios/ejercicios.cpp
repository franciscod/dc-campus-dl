#include "ejercicios.h"

// vectores + recursion

// vectores + recursion
bool divide(vector<int> v, int n){
  cout << "Implementar" << std::endl;
}
bool divideRec(vector<int> v, int n){
  cout << "Implementar" << std::endl;
}

int maximo(vector<int> v){
  cout << "Implementar" << std::endl;
}
int maximoRec(vector<int> v){
  cout << "Implementar" << std::endl;
}

bool pertenece(int elem, vector<int> v){
  cout << "Implementar" << std::endl;
}
bool perteneceRec(int elem, vector<int> v){
  cout << "Implementar" << std::endl;
}

// vectores
vector<int> rotar(vector<int> v, int k){
  cout << "Implementar" << std::endl;
}
vector<int> reverso(vector<int> v){
  cout << "Implementar" << std::endl;
}
vector<int> factoresPrimos(int n){
  cout << "Implementar" << std::endl;
}
void mostrarVector(vector<int> v){
  cout << "Implementar" << std::endl;
}
bool estaOrdenado(vector<int> v){
  cout << "Implementar" << std::endl;
}


// integradores
void negadorDeBooleanos(vector<bool> &booleanos){
  cout << "Implementar" << std::endl;
}
void palindromos(string rutaArchivoIn, string rutaArchivoOut){
  cout << "Implementar" << std::endl;
}
void promedios(string rutaArchivoIn1, string rutaArchivoIn2, string rutaArchivoOut){
  cout << "Implementar" << std::endl;
}
void cantidadApariciones(string rutaArchivo, string rutaArchivoOut){
  cout << "Implementar" << std::endl;
}
int cantidadAparicionesDePalabra(string rutaArchivo, string palabra){
  cout << "Implementar" << std::endl;
}
void estadisticas(string rutaArchivo){
  cout << "Implementar" << std::endl;
}
void intersecion(){
  cout << "Implementar" << std::endl;
}
