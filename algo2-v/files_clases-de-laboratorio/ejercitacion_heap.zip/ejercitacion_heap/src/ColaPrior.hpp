
template<class T>
ColaPrior<T>::ColaPrior() {
	// COMPLETAR
}

template<class T>
int ColaPrior<T>::tam() const {
	// COMPLETAR
}

template<class T>
void ColaPrior<T>::encolar(const T& elem) {
	// COMPLETAR
}

template<class T>
const T& ColaPrior<T>::proximo() const {
	// COMPLETAR
}

template<class T>
void ColaPrior<T>::desencolar() {
	// COMPLETAR
}

template<class T>
ColaPrior<T>::ColaPrior(const vector<T>& elems) {
	// COMPLETAR
}

