import Util
import Data.Maybe
import Data.List

-- Ejercicio 1
singleton:: Eq t => t -> Anillo t
singleton = undefined

insertar :: Eq t => t -> Anillo t -> Anillo t
insertar = undefined

avanzar :: Anillo t -> Anillo t
avanzar = undefined

-- Ejercicio 2

enAnillo:: Eq t => t -> Anillo t -> Bool
enAnillo = undefined

-- Ejercicio 3
filterAnillo :: Eq t => (t -> Bool) -> Anillo t -> Maybe (Anillo t)
filterAnillo = undefined

-- Ejercicio 4

mapAnillo:: Eq a => Eq b => (a -> b) -> Anillo a -> Anillo b
mapAnillo = undefined

--Ejercicio 5
palabraFormable :: String -> [Anillo Char] -> Bool
palabraFormable = undefined

--Ejercicio 6
anillos:: Eq a => [a] -> [Anillo a]
anillos = undefined
