module TypeInferenceMonad (TypingJudgment, Error(..), inferType)

where

import List(intersect)
import Exp
import Type
import Unification

------------
-- Errors --
------------

data Error a = OK a | Error String

spreadError :: Error a -> (a -> Error b) -> Error b
spreadError (OK a) f = f a
spreadError (Error s) _ = Error s

returnE :: a -> Error a
returnE = OK

failE :: String -> Error a
failE = Error

------------------
-- Typing State --
------------------

data TypingState a = TS (Int->Error (Int, a))

applyTS :: TypingState a -> Int -> Error (Int, a)
applyTS (TS f) = f

instance Monad TypingState where
  
  return a = TS (\n -> returnE (n, a))
  (>>=) = spreadTypingState

spreadTypingState :: TypingState a -> (a -> TypingState b) -> TypingState b
spreadTypingState tsa f = TS (\n->spreadError (applyTS tsa n) (\(n', a) -> applyTS (f a) n'))

returnTS :: a -> TypingState a
returnTS a = TS (\n -> returnE (n, a))

errorTS :: String -> TypingState a
errorTS s = TS (const $ failE s)

freshTS :: TypingState Type
freshTS = TS (\n -> returnE (n+1, TVar n))

unifTS :: [UnifGoal] -> TypingState Subst
unifTS types = case mgu types of
                  UOK subst -> returnTS subst
                  UError u1 u2 -> uErrorTS u1 u2

uErrorTS :: Type -> Type -> TypingState a
uErrorTS t1 t2 = TS (const $ uError t1 t2)

--------------------
-- Type Inference --
--------------------

type TypingJudgment = (Env, AnnotExp, Type)

inferType :: PlainExp -> Error TypingJudgment
inferType e = case applyTS (infer' e) 0 of
    OK (_, tj) -> OK tj
    Error s -> Error s

infer' :: PlainExp -> TypingState TypingJudgment
infer' (VarExp x)     = do
			  freshT <- freshTS
                          return (extendE emptyEnv x freshT, VarExp x, freshT)
infer' ZeroExp        = return (emptyEnv, ZeroExp, TNat)
infer' (SuccExp e)    = do
			  (env', e', t') <- infer' e
			  subst <- unifTS [(t', TNat)]
                          return (subst <.> env',
                                       subst <.> SuccExp e',
                                        TNat)
infer' (PredExp e)    = do
			  (env', e', t') <- infer' e 
			  subst <- unifTS [(t', TNat)] 
                          return (subst <.> env',
                                       subst <.> PredExp e',
                                        TNat)
infer' (IsZeroExp e)  = do
			  (env', e', t') <- infer' e
			  subst <- unifTS [(t', TNat)]
                          return (subst <.> env',
                                       subst <.> IsZeroExp e',
                                        TBool)
infer' TrueExp        = return (emptyEnv, TrueExp, TBool)
infer' FalseExp       = return (emptyEnv, FalseExp, TBool)
infer' (IfExp u v w)  = do
			(env1, u', t1) <- infer' u
			(env2, v', t2) <- infer' v
                        (env3, w', t3) <- infer' w
			s <- let goals = (t1, TBool)
					      :(t2, t3)
						 :(getGoals env1 env2)++(getGoals env1 env3)++(getGoals env2 env3)
				in unifTS goals
                        return (joinE $ map (s <.>) [env1, env2, env3],
                                            s <.> IfExp u' v' w',
                                              s <.> t2)
infer' (LamExp x _ e) = do
			 (env', e', t) <- infer' e
			 tx <- evalOrFresh env' x
                         return (removeE env' x, LamExp x tx e', TFun tx t)
infer' (AppExp u v)   = do
			 (env1, u', t1) <- infer' u
                         (env2, v', t2) <- infer' v
                         freshT <- freshTS
                         s <- let goals = getGoals env1 env2
                              in (unifTS $ (t1, TFun t2 freshT) : goals)
                         return (joinE $ map (s <.>) [env1, env2],
                                             s <.> AppExp u' v',
                                              s <.> freshT)

getGoals :: Env -> Env -> [UnifGoal]
getGoals env1 env2 = [(evalE env1 x, evalE env2 x) |
                        x <- intersect (domainE env1) (domainE env2)]

uError :: Type -> Type -> Error a
uError t1 t2 = Error $ "Cannot unify " ++ show t1 ++ " and " ++ show t2

evalOrFresh :: Env -> Symbol -> TypingState Type
evalOrFresh env x | x `elem` (domainE env) = returnTS $ evalE env x
                  | otherwise = freshTS

removeAllE :: Env -> [Symbol] -> Env
removeAllE env = foldr (flip removeE) env
