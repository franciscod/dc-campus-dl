#ifndef CASES_INCLUDED_H
#define CASES_INCLUDED_H

using namespace std;

bool test01_division();
bool test02_existePico();
bool test03_mcd();
bool test04_indiceMinSubsec();
bool test05_ordenar1();
bool test06_ordenar2();

#endif //CASES_INCLUDED_H
