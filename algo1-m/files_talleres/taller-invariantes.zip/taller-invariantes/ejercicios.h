#ifndef SRC_EJERCICIOS_H_
#define SRC_EJERCICIOS_H_

#include <vector>
#include <utility>
#include <tuple>
using namespace std;

// Ejercicio 1
tuple<int,int> division(int n, int d);
// Ejercicio 2
bool existePico(vector<int> v);
// Ejercicio 3
int mcd(int m, int n);
// Ejercicio 4
int indiceMinSubsec(vector<int> v, int i, int j);
// Ejercicio 5
void ordenar1(vector<int>& v);
// Ejercicio 6
void ordenar2(vector<int>& v);

#endif /* SRC_EJERCICIOS_H_ */
