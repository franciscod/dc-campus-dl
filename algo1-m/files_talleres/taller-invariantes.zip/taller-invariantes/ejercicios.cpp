#include "../template-alumnos/ejercicios.h"


// Ejercicio 1
tuple<int,int> division(int n, int d){
	return make_tuple(0,0);
}

// Ejercicio 2
bool existePico(vector<int> v){
	return true;
}

// Ejercicio 3
int mcd(int m, int n){
	return 0;
}

// Ejercicio 4
int indiceMinSubsec(vector<int> v, int l, int r){
	return 0;
}

// Ejercicio 5
void ordenar1(vector<int>& v){
	return;
}

// Ejercicio 6
void ordenar2(vector<int>& v){
	return;
}