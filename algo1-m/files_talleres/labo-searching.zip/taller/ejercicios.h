#include <vector>
using namespace std;

int buscar(vector<int> v, int x);
int indicePico(vector<int> v);
int decimoPrimo(int a);
int puntoFijo(vector<int> v);
int encontrarRotado(vector<int> v, int x);
int menorMasGrande(vector<int> v, int x);
vector<int> masCercanoK(vector<int> v, int k,  int x);