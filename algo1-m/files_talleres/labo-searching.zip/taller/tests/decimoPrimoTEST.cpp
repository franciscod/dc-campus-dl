#include "../ejercicios.h"
#include "gtest/gtest.h"


TEST(decimoPrimo, desde4){
	int a = 4;
	int res = decimoPrimo(a);
	ASSERT_EQ(37, res);
}

TEST(decimoPrimo, desde6){
	int a = 5;
	int res = decimoPrimo(a);
	ASSERT_EQ(37, res);
}

TEST(decimoPrimo, desde8){
	int a = 8;
	int res = decimoPrimo(a);
	ASSERT_EQ(43, res);
}

TEST(decimoPrimo, desde25){
	int a = 25;
	int res = decimoPrimo(a);
	ASSERT_EQ(67, res);
}