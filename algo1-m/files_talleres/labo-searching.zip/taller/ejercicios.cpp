#include "ejercicios.h"

int jumpSearch(vector<int> v, int x){
	return -1;
}

int exponentialSearch(vector<int> v, int x){
	return -1;
}

int buscar(vector<int> v, int x){
	// Descomentar el que se usa
     return jumpSearch(v,x);
    // return exponentialSearch(v,x);
}

int indicePico(vector<int> v){
	return -1;
}

int decimoPrimo(int a){
	return -1;
}

int puntoFijo(vector<int> v){
	return -1;
}

int encontrarRotado(vector<int> v, int x){
	return -1;
}

int menorMasGrande(vector<int> v, int x){
	return -1;
}

vector<int> masCercanoK(vector<int> v, int k,  int x){
	return {};
}