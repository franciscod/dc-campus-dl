int llenarTaxis1(int g1, int g2, int g3);
int llenarTaxis2(int g1, int g2, int g3);
int llenarTaxis3(int g1, int g2, int g3);
