int puntaje(int b);
