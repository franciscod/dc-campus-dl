bool esPrimo(int n);
