int baldosasDelPiso(int M, int N, int B);
