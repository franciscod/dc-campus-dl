#include "../electores.h"
#include "gtest/gtest.h"

// Escribir tests aca:
