
#define NO_VOTA             0
#define OPCIONAL_MENOR      1
#define OBLIGATORIO         2
#define OPCIONAL_MAYOR      3
#define ERROR               4

int validarVotante(int a, int m, int d);
