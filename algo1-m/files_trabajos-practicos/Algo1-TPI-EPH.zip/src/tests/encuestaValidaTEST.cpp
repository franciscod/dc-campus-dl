#include "../Funciones_TPI.h"
#include "../ejercicios.h"
#include "gtest/gtest.h"
#include <iostream>
#include <string>

using namespace std;

TEST(encuestaValidaTEST, unaValida) {
    eph t1 = leerEncuesta("datos/eth_01.csv");
    EXPECT_EQ(true,esEncuestaValida(t1));
}

TEST(encuestaValidaTEST, noValida) {
    eph t1 = leerEncuesta("datos/eth_02.csv");
    EXPECT_EQ(false,esEncuestaValida(t1));
}
