#include "ejercicios.h"



bool esEncuestaValida(eph t){

    return true;
}

int laMejorEdad(eph t){

    return 0;
}

float promedioIngresoProfesional(eph t){

    return 0.0;
}

int hogarDeMayorIngreso(eph t){

    return 0;
}

individuo mejorNoProfesional(eph t){

    individuo ind;
    return ind;
}

bool sigoEstudiando(eph t){

    return true;
}

individuo empleadoDelAnio(eph t){

    individuo ind;

    return ind;
}

bool noTieneAQuienCuidar(eph t){

    return true;
}

bool pareto(eph t){

    return true;
}

int elDeMayorIncrementoInterAnual(eph t1, eph t2){

    return 0;
}

vector<tuple<int,float>> mejorQueLaInflacion(eph t1, eph t2, float infl){

    vector<tuple<int,float>> result;

    return result;
}

void ordenar(eph &t){

}

void agregarOrdenado(eph &t, individuo ind){

}

void quitar(eph &t, individuo ind){

}