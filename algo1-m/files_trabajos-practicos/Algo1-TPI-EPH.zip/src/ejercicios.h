#ifndef ETPH_EJERCICIOS_H
#define ETPH_EJERCICIOS_H

#include <iostream>
#include <vector>
#include <math.h>
#include <tuple>
#include "definiciones.h"

using namespace std;

bool esEncuestaValida(eph t);
int laMejorEdad(eph t);
float promedioIngresoProfesional(eph t);
int hogarDeMayorIngreso(eph t);
individuo mejorNoProfesional(eph t);
bool sigoEstudiando(eph t);
individuo empleadoDelAnio(eph t);
bool noTieneAQuienCuidar(eph t);
bool pareto(eph t);
int elDeMayorIncrementoInterAnual(eph t1, eph t2);
vector<tuple<int,float>> mejorQueLaInflacion(eph t1, eph t2, float infl);
void ordenar(eph &t);
void agregarOrdenado(eph &t, individuo ind);
void quitar(eph &t, individuo ind);

#endif //ETPH_EJERCICIOS_H
