package dc.aap;

public class SomeClass {

	public static void entryPoint() {
		int i,j,k;
		i = 10;
		j = 20;
		k = i+j;
	}
	
}
