# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import matplotlib.pylab as pl
from PIL import Image
import numpy as np
from graph import Vertex, Edge
from DSU import DSU
from scipy.ndimage import gaussian_filter
import scipy
import sys
import tqdm

def load_image(infilename):
    img = Image.open(infilename)
    img.load()
    img = img.convert('L')
    data = np.asarray(img, dtype="int32")
    return data

def save_image(npdata, outfilename) :
    img = Image.fromarray(np.asarray(np.clip(npdata,0,255), dtype="uint8"), "L")
    img.save(outfilename)

def weight(i1, j1, i2, j2, image):
	return abs(image[i1][j1] - image[i2][j2])

def MInt(C1, C2, k):
	return min(C1.int + float(k) / C1.size, C2.int + float(k) / C2.size)

class Component:
	def __init__(self, v, id):
		self.id = id
		self.v = [v]
		self.size = 1
		self.int = 0

	def __eq__(self, other):
		return self.id == other.id

def segmentation(V, E, k):

	# Sort E into pi = (o 1 , . . . , o m ), by non-decreasing edge weight.
	E = sorted(E, key=lambda e: e.weight)

	# Start with a segmentation S 0 , where each vertex v i is in its own component.
	S = [Component(V[i], i) for i in range(len(V))]
	dsu = DSU(len(S))

	# Repeat step 3 for q = 1, . . . , m.
	for e in tqdm.tqdm(E, total=len(E)):

		# Construct S q given S q1
		vi = V.index(e.v1)
		vj = V.index(e.v2)
		
		c1 = S[dsu.find(vi)]
		c2 = S[dsu.find(vj)]

		if c1 != c2 and e.weight < MInt(c1, c2, k):
			dsu.union(vi, vj)
			final_c = S[dsu.find(vi)]
			final_c.size = c1.size + c2.size
			final_c.int = e.weight

			'''
			c_merged = S[dsu.find(vi)]

			if c_merged == c1:
				c_merged.v += c2.v
				c2.v = []
			else:
				c_merged.v += c1.v
				c1.v = []
			
			c_merged.int = e.weight
			'''

	# Return S = S m
	return dsu
	# return filter(lambda c: len(c.v) > 0, S)

if __name__ == '__main__':

	k = float(sys.argv[1])
	sigma = float(sys.argv[2])
	image_path = sys.argv[3]

	print "Cargando imagen"
	image = load_image(image_path)
	print "Tamaño de la imagen:", image.shape


	plt.matshow(image, cmap="gray")
	plt.show()

	print "Aplico filtro gaussiano"
	image = gaussian_filter(image, sigma=sigma)
	plt.matshow(image, cmap="gray")
	plt.show()

	print "Calculando los vertices"
	V = [Vertex(i, j) for i in range(image.shape[0]) for j in range(image.shape[1])]
	print "Cantidad de nodos: ", len(V)

	print "Calculando los ejes"
	E = [Edge(Vertex(i, j), Vertex(i + ofset_i, j + ofset_j), weight(i, j, i + ofset_i, j + ofset_j, image)) 
			for i in range(1, image.shape[0] - 1, 2)
			for j in range(1, image.shape[1] - 1, 2)
			for ofset_i in [-1, 0, 1] 
			for ofset_j in [-1, 0, 1]
			if (ofset_i != 0 or ofset_j != 0)]

	print "Cantidad de ejes", len(E)

	print "mostrando resultado"
	result = [[255 for j in range(image.shape[1])] for i in range(image.shape[0])]

	print "Segmentando"
	segments = segmentation(V, E, k)
	colors = {}
	current_color = 0

	# Utilizo el representante de cada nodo (pixel) para pintar cada 
	# componente del color de su representante
	for i in range(len(V)):
		component = segments.find(i)
		if component not in colors.keys():
			colors[component] = current_color
			current_color += 1
		v = V[i]
		result[v.i][v.j] = colors[component]

	result = np.array(result)
	plt.matshow(result, cmap=pl.cm.tab20)
	plt.show()