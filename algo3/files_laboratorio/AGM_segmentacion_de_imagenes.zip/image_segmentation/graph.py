class Edge:
	def __init__(self, v1, v2, w):
		self.v1 = v1
		self.v2 = v2
		self.weight = w

class Vertex:
	def __init__(self, i, j):
		self.i = i
		self.j = j

	def __eq__(self, other):
		return self.i == other.i and self.j == other.j