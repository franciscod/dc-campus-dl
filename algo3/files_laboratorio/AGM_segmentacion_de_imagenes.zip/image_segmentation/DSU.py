class DSU:

    def __init__(self, n):
        self.altura = []
        self.padre = []
        for i in range(n):
            self.altura.append(1)
            self.padre.append(i)

    def find(self, x):
        if self.padre[x] != x:
            self.padre[x] = self.find(self.padre[x]) # compression path

        return self.padre[x]

    def union(self, x, y):
        x = self.find(x)
        y = self.find(y)
        if self.altura[x] < self.altura[y]:
            self.padre[x] = y
        else:
            if self.altura[x] == self.altura[y]:
                self.altura[x] += 1
            self.padre[y] = x
