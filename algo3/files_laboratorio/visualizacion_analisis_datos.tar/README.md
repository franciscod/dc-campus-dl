# Clase algoritmos y estructuras de datos 
## Titulo: Introducción al análisis y visualización de datos con Python.  

## Pre requisitos:
- [Python] https://www.python.org
- [Jupyter notebook] http://jupyter.readthedocs.io/en/latest/install.html
- [Pandas] http://pandas.pydata.org
- [seaborn] https://seaborn.pydata.org
- [matplotlib] http://matplotlib.org
- [numpy] http://www.numpy.org

## Links relevantes:

- http://pandas.pydata.org/pandas-docs/stable/tutorials.html
- http://pandas.pydata.org/pandas-docs/stable/10min.html
- http://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.plot.html
