#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <cstring>
#include <stack>
#include <algorithm>
#include <math.h>
 
//Problema: http://www.spoj.com/problems/ROHAAN/ 

using namespace std;
 
#define forsn(i,s,n) for(int i = (s); i < (int)(n); i++)
#define forn(i,n) forsn(i,0,n)

//Como el grafo es completo, me guardo todas las distancias entre pares de vertices
int dists[64][64];
 
void relax(int from, int middle, int to) {
	if (dists[from][to] > dists[from][middle] + dists[middle][to]) {
		dists[from][to] = dists[from][middle] + dists[middle][to];
	}
}
 
int main(){
	int test_cases; cin >> test_cases;
	forn(t, test_cases) {
		int size; cin >> size;
		forn(i, size) {
			forn(j, size){
				cin >> dists[i][j];
			}
		}
		//Corro el forforfor de Floyd-Warshall
		forn(k, size) {
			forn(i, size) {
				forn(j, size) {
					relax(i, k, j);
				}
			}
		}
		//Ahora en dists tengo la minima distancia para todo par de vertices
		int ret = 0;
		int ops; cin >> ops;
		//Para cada operacion "calculo" su costo y voy sumando al resultado final
		forn(i, ops) {
			int from, to; cin >> from >> to;
			ret += dists[from - 1][to - 1];
		}
		cout << "Case #" << t + 1 << ": " << ret << endl;
	}
} 
