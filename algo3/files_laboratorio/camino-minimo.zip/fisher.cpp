#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <cstring>
#include <stack>
#include <algorithm>
#include <math.h>
 
//Problema: http://www.spoj.com/problems/FISHER/ 

/* Idea de la solucion:
 * +Considero a los estados (c, t): "estoy en la ciudad c y me queda tiempo t hasta que se me pudra el pescado".
 * +Considero al grafo donde cada nodo es uno de esos estados: esto se puede pensar como que tenemos el grafo original
 * con t pisos, uno por cada cantidad de tiempo restante posible.
 * 	+Por ejemplo si ir de la ciudad c1 a la ciudad c2 nos cobran p1 pesos y nos cuesta t1 tiempo, entonces,
 * 	hay una arista del nodo-estado (c1, t) al nodo-estado (c2, t-t1) cuyo costo es p1.
 * +Resolver el problema pasa a ser calcular el camino minimo desde el estado inicial (ciudadInicial, tiempoInicial)
 * hacia cualquiera de los estados que terminen en la ciudad final (el mercado). Con correr un dijkstra estamos.
 * */

using namespace std;
 
#define forsn(i,s,n) for(int i = (s); i < (int)(n); i++)
#define forn(i,n) forsn(i,0,n)
 
int INF = 2147483647;

//Aca me guardo las distancias que va calculando el dijsktra, empiezan todas en INF (lo seteo en el main).
int dist[1000][50];

//El grafo original es completo, pero ojo, el grafo generado de nodo-estados no necesariamente lo es.
int toll[50][50];
int times[50][50];

// Me armo una estructura que representa a un estado (ciudad, tiemporestante).
// Tambien incluyo el campo dist, que corresonde a la distancia calculada por el algoritmo de dijkstra hasta el momento.
// Notar que en ningún lugar me guardo las transiciones de estado a estado (aristas), ya que las puedo calcular en el momento.
// Una ventaja de calcular los nodos "on the fly" es que no guardo en memoria nodos que no necesito.
// Por ejemplo, si es imposible llegar al nodo (ci, ti), nunca lo calculo.
struct State {
	int dist, time, city;
	State() {}
	State(int a, int b, int c) { dist = a; time = b; city = c; }
	//A este operador lo defino para poder ordenar de menor a mayor en la priority queue
	bool operator>(const State &s) const { return dist > s.dist; }
};
 
void solve(int cities, int init_time) {
	//Esto es una priority_queue de State ordenada por el operador ">" definido antes
	//O sea, pq.pop() me devuelve el State de menor dist.
	priority_queue<State, vector<State>, greater<State> > pq;
	dist[init_time][0] = 0;
	pq.push(State(0, init_time, 0)); //Agregamos el estado-nodo inicial a la cola
	while (!pq.empty()) {
		State s = pq.top(); pq.pop();
		
		//Este if es para no revisar nodos que ya revise, ya que voy a poner varis State con (time, city) repetidos.
		//La gracia es que como voy mirando de la dist mas chica a la dist mas grande (por el orden la pq)
		//si ya los revise, en dist[time][city] tengo un numero menor.
		if (dist[s.time][s.city] < s.dist) continue;
		
		//Este for if equivale a iterar los vecinos en el grafo de estados.
		//Como se explica arriba, se calculan los vecinos basandose en el grafo original (el de ciudades).
		forn(new_city, cities) {
			if (times[s.city][new_city] <= s.time) {
				int new_time = s.time - times[s.city][new_city];
				//El estado vecino del estado (s.time, s.city) vendria a ser (new_time, new_city)
				if (dist[s.time][s.city] + toll[s.city][new_city] < dist[new_time][new_city]) {
					int new_dist = dist[s.time][s.city] + toll[s.city][new_city];
					dist[new_time][new_city] = new_dist;
					
					//Agrego a la cola los estados vecinos. Ojo, aca puedo meter (time,city) repetidos.
					//Peeero, como ordeno por dist (operator > de State), cuando haga pq.pop() voy a sacar el mas chico :)
					//Entonces, si miro un estado con (time,city) que ya mire antes, quiere decir que ya lo miré con dist menor
					//Esto va a hacer que el if continue de mas arriba lo descarte :)
					pq.push(State(new_dist, new_time, new_city));
				}
			}
		}
	}
	
	int used_traveling_time = -1;
	int tolls_paid = INF;
	
	//Chequeo todos los estados que llegan al mercado y me quedo con el mas cercano
	forn(t, init_time) {
		if (dist[t][cities - 1] < tolls_paid) {
			tolls_paid = dist[t][cities - 1];
			used_traveling_time = init_time - t;
		}
	}
	
	cout << tolls_paid << " " << used_traveling_time << endl;
	
}
	
int main() {
	int cities, time; cin >> cities >> time;
	while (cities != 0 && time != 0) {
		//leo los tiempos de ciudad a ciudad
		forn(i, cities) {
			forn(j, cities) {
				cin >> times[i][j];
			}
		}
		//leo los peajes de ciudad a ciudad
		forn(i, cities) {
			forn(j, cities) {
				cin >> toll[i][j];
			}
		}
		//Las distancias inciales empiezan en INF.
		forn(t, time) {
			forn(c, cities) {
				dist[t][c] = INF;
			}
		}
		//Corro el dijkstra
		solve(cities, time);
		
		cin >> cities >> time;
	}
	return 0;
}
