#include <stdio.h>
void blit_c (unsigned char *src, unsigned char *dst, int w, int h, int src_row_size, int dst_row_size, unsigned char *blit, int bw, int bh, int b_row_size) {
	//COMPLETAR
}
