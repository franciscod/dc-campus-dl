#ifndef __IMAGENES__H__
#define __IMAGENES__H__

void imagenes_abrir(configuracion_t *config);
void imagenes_guardar(configuracion_t *config);
void imagenes_liberar();


#endif /* !__IMAGENES__H__ */
