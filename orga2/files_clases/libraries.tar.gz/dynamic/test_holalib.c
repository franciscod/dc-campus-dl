/* Programa de prueba para nuestra librería holalib
*/

# include "holalib.h"
# include <dlfcn.h>
# include <stdlib.h>

int	main (int argc, char **argv)
{
	void *handle;
	void (*hello) (void);
	char *error;

	handle = dlopen("../shared/libhola.so.1",RTLD_LAZY);

	if (!handle) {
		fprintf (stderr, "%s\n", dlerror());
		exit(EXIT_FAILURE);
	}

	hello = dlsym (handle, "hola");
	if ((error = dlerror()) != NULL) {
		fputs(error, stderr);
	exit(EXIT_FAILURE);
	}

	(*hello) ();
	dlclose(handle);

	return 0;
}
