/* Header para holalib.c
*/
#ifndef HOLA_H
#define HOLA_H

# include <stdio.h>

void	hola (void);
#endif

