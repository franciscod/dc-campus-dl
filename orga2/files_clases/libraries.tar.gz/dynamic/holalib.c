/* Programa holalib.c
Ejemplo simple para generar una librería.
La función hola que imprime en stdout el viejo y querido Hola Mundo!
*/

#include "holalib.h"

void	hola (void)
{
	printf ("Hola Mundo!\n");
}

