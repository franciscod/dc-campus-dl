/*Programa de prueba para nuestra Biblioteca libhola*/

# include "holalib.h"

int main ( void )
{
	hola ( ) ;
	return 0;
}
