/* Problema1: Hallar la suma de todos los múltiplos de 3 o de 5 menores a 1000 */

#include <iostream>

using namespace std;

int main () {

  int n = 1000;
  int sumaTotal = 0;

  int i = 0;
  while ( i<n ){
    if ( i%3 == 0 || i%5 == 0 )
      {sumaTotal = sumaTotal+i;}
    i = i+1;
  }
  
  cout << sumaTotal << endl;

  return 0;

}
