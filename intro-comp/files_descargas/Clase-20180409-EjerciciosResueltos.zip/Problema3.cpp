/* Problema3: Hacer un programa que decida si una lista es picuda */

/* 

Observación: una lista es picuda sii no tiene pozos (un pozo es una sublista de ìndices i,i+1,...,i+k/ L[i]=...=L[i+k]=C con L_(i-1)>C y L_(i+k+1)>C. Gráficamente sería algo así:

\         /
 \       /
  \     /
   _____ 

Por ejemplo, la lista [5,4,3,3,3,3,3,9,14] tiene un pozo a partir del índice 2.

*/

#include <iostream>
#include <vector>
using namespace std;

/* Declaración de funciones auxiliares */
bool hayUnPozoEn(vector<int>,int);
bool esPicuda (vector<int>);
/***************************************/

int main (){

  cout << "Por favor, introducí los números naturales de tu lista (para terminar, ingresá 0)" << endl;

  vector<int> lista;
  
  int c = 0;
  cin >> c;
  while (c>0){
    lista.push_back(c);
    cin >> c;
  }
  
  cout << "La lista que ingresaste ";

  if (esPicuda(lista))
    cout << "es picuda." << endl;
  else if (!esPicuda(lista))
    cout << "no es picuda." << endl;
  
  return 0;
  
}

/* Implementación de funciones auxiliares */

bool esPicuda (vector<int> v){
  //requiere que el vector no sea vacío
  
  if ( v.size() == 1 || v.size() == 2 )
    return true; //Si tiene uno o dos elementos, termina y devuelve true
  
  bool aux = true;
  
  int i = 1;
  while ( i < v.size()-1 ){

    if ( hayUnPozoEn(v,i) )
      aux = false;

    i = i+1;

  }

  return aux;
}

bool hayUnPozoEn (vector<int> v, int i){
  // requiere que 0 < i < v.size()-1
  // ( o sea, el elemento i tiene que tener dos vecinos )

  int j = i;
  while ( j<v.size() && v[j]==v[i] )
    j = j+1;
  
  bool pozo = (v[i-1]>v[i])&&(v[j]>v[i]);  
  
  return pozo;
}
