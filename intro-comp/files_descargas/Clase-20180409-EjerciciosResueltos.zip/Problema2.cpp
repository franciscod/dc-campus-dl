/* Problema2: hallar la suma de los términos pares de la sucesión de fibonacci que sean más chicos que 4 millones */

/* Observación: la sucesión de fibonacci está dada por:
   0,1,1,2,3,5,8,13,21,34,....
   Los términos pares son los que aparecen en posiciones múltiplos de tres. */

#include <iostream>
#include <vector>

using namespace std;

/* Declaración de funciones auxiliares: */
vector<int> fibonacciMenoresQue (int);

int main () {

  int n = 4000000;
  vector<int> fibo = fibonacciMenoresQue(n);
  
  int i = 0;
  int suma = 0;
  
  while ( i < fibo.size() ){

    suma = suma + fibo[i];
    i = i+3; //Sólo me muevo por los índices múltiplos de tres

  }

  cout << suma << endl;

  return 0;
}


/* Implementación de funciones auxiliares: */

//Devuelve un vector con los términos de fibonacci menores a n
vector<int> fibonacciMenoresQue (int n){

  vector<int> terminos;

  terminos.push_back(0);
  terminos.push_back(1);

  int i = 2;

  while ( terminos[i-2]+terminos[i-1] <= n ){
    
    terminos.push_back(terminos[i-2]+terminos[i-1]);
    i = i+1;
  }

  return terminos;
}
    
