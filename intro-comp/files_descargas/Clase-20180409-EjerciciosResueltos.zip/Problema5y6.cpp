/* Problema5: dado un texto sin espacios al comienzo ni al final, programar una función que cuente la cantidad de palabras que tiene */
/* Problema6: dado un texto que puede tener espacios en blanco al comienzo, programar una función que cuente la cantidad de palabras que tiene usando la función anterior */

#include <iostream>
#include <string> //Vamos a usar las funciones "getline" y "substr"

using namespace std;

/* Declaración de funciones auxiliares: */
string sacaEspacios(string);
int cantidadDePalabrasSinEspacios(string);    //La del problema 5
int cantidadDePalabras(string);               //La del problema 6
/******************************************/

int main () {

  string texto;

  cout << "Por favor, ingresá un texto: " << endl;
  getline (cin, texto);
  //El texto que ingresaste se guardó en la variable "texto"
  
  // cout << texto << endl;

  // cout << sacaEspacios(texto) << endl;
  
  cout << "El texto que ingresaste tiene " << cantidadDePalabras(texto) << " palabras." << endl;

  return 0;
}

/* Implementación de funciones auxiliares: */

int cantidadDePalabrasSinEspacios (string str){
  //requiere que str no tenga espacios al principio ni al final
  
  int i = 0;
  int palabras = 0;

  while ( i < str.length()-1 ){
    if (str[i]!=' ' && str[i+1]==' ')
      {palabras = palabras+1;}
    i = i+1;
  }
  //Ahora palabras almacena la cantidad de letras de str que son seguidas por un espacio

  return palabras+1;
  //Pero nos faltaba agregar la última palabra del texto
}  

string sacaEspacios (string str){
  //Esta función devuelve la substring de str con los espacios al principio y al final extirpados

  int i = 0;
  while ( str[i]==' ' ) 
    i=i+1;
  //Ahora i guarda el índice del primer elemento que no es espacio

  int f = str.length()-1;
  while ( str[f]==' ' )
    {f=f-1;}
  //Ahora f guarda el índice del último elemento que no es espacio
  
  string pedazo = str.substr(i,f+1-i);
  //La función substr agarra las f+1-i letras que vienen después de la posición i. 

  return pedazo;
}


int cantidadDePalabras (string str){

  string pedazo = sacaEspacios(str);

  return cantidadDePalabrasSinEspacios(pedazo);

}
  
