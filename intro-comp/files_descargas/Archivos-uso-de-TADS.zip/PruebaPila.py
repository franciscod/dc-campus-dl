from Pila import *

p = Pila()
p.apilar(3)
print p.tope()
p.apilar(6)
print p.tope()

while not p.vacia():
	p.desapilar()	

