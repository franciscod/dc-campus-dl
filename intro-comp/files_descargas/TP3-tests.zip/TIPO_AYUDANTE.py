
class Ayudante:
  def __init__(self):
    pass

  def cantidadDePalabras(self):
    return 0 

  def agregarPalabra(self, p): # p:string, correspondiente a una palabra
    pass

  def palabrasPosibles(self, p): # p:s(tring, con las letras a usar
    return {}

  def existe(self, p): # p:string, correspondiente a una palabra
    return False 
