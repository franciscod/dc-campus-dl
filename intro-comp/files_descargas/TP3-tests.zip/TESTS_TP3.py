from TIPO_AYUDANTE import Ayudante
import sys


###############################################################################################

def printTestResult(result, testNum):
	if result:
		print('Test ' + str(testNum) + ' --------> OK')
	else:
		print('Test ' + str(testNum) + ' --------> FALLO')
		sys.exit(1)

###############################################################################################

def test1():
	# Chequeo de Ayudante vacio
	res = True
	l = Ayudante()
	res = res and l.cantidadDePalabras() == 0
	res = res and not l.existe("almacen")
    
    # Ayudante vacio devuelve vacio para cualquier conjunto de palabras
	res = res and len(l.palabrasPosibles("perro")) == 0
	printTestResult(res, 1)

###############################################################################################

def test2():
	# Chequeo agregar dos palabras
	res = True
	l = Ayudante()
	res = res and l.cantidadDePalabras()==0
	p1 = "alameda"
	p2 = "gerardo"
	l.agregarPalabra(p1)
	l.agregarPalabra(p2)
	res = res and l.existe(p1)
	res = res and l.existe(p2)
	res = res and l.cantidadDePalabras() == 2

	# "alameda" es la unica palabra posible para sus letras
	s1 = l.palabrasPosibles("alameda")
	res = res and len(s1) == 1 and "alameda" in s1

	# prueba con algun anagrama de "alameda"
	s1 = l.palabrasPosibles("medaala")
	res = res and len(s1) == 1 and "alameda" in s1
	# el anagrama no era palabra conocida, no debe ser parte de las opciones
	res = res and "medaala" not in s1
	
	printTestResult(res, 2)

###############################################################################################

def test3():
	# Chequeo de existe
	res = True
	l = Ayudante()
	p1 = "alameda"
	p2 = "gerardo"
	res = res and not l.existe(p1)
	res = res and not l.existe(p2)
	l.agregarPalabra(p1)
	res = res and l.existe(p1)
	res = res and not l.existe(p2)
	l.agregarPalabra(p2)
	res = res and l.existe(p1)
	res = res and l.existe(p2)
	printTestResult(res, 3)

###############################################################################################

def test4():
	# Chequeo funcionamiento con 18 palabras
	res = True
	p1 = "indec"
	p2 = "cedin"
	p3 = "otro"
	p4 = "toro"
	p5 = "roto"
	p6 = "pelado"
	p7 = "minusculo"
	p8 = "bisiesto"
	p9 = "parciales"
	p10 = "colegio"
	p11 = "dedo"
	p12 = "edad"
	p13 = "fierro"
	p14 = "gato"
	p15 = "hola"
	p16= "jalea"
	p17= "zeta"
	p18 = "otrora"
	# se agregan las 18 palabras al Ayudante
	l = Ayudante()
	l.agregarPalabra(p1)
	l.agregarPalabra(p2)
	l.agregarPalabra(p3)
	l.agregarPalabra(p4)
	l.agregarPalabra(p5)
	l.agregarPalabra(p6)
	l.agregarPalabra(p7)
	l.agregarPalabra(p8)
	l.agregarPalabra(p9)
	l.agregarPalabra(p10)
	l.agregarPalabra(p11)
	l.agregarPalabra(p12)
	l.agregarPalabra(p13)
	l.agregarPalabra(p14)
	l.agregarPalabra(p15)
	l.agregarPalabra(p16)
	l.agregarPalabra(p17)
	l.agregarPalabra(p18)
	# se borra p1 y se cheque pertenencia
	# se chequea pertenencia
	res = res and l.existe(p1) 
	res = res and l.existe(p2) 
	res = res and l.existe(p3) 
	res = res and l.existe(p4) 
	res = res and l.existe(p5) 
	res = res and l.existe(p6) 
	res = res and l.existe(p7) 
	res = res and l.existe(p8) 
	res = res and l.existe(p9) 
	res = res and l.existe(p10) 
	res = res and l.existe(p11) 
	res = res and l.existe(p12) 
	res = res and l.existe(p13) 
	res = res and l.existe(p14) 
	res = res and l.existe(p15) 
	res = res and l.existe(p16) 
	res = res and l.existe(p17)
	printTestResult(res, 4)

###############################################################################################

def test5():
	# chequeo palabra vacia
	res = True
	l = Ayudante()
	res = res and not l.existe("")
	l.agregarPalabra("")
	res = res and l.existe("")
	res = res and not l.existe("pirulo")
	printTestResult(res, 5)

###############################################################################################

def test6():
	# chequeo agregar dos veces una palabra
	res = True
	l = Ayudante()
	l.agregarPalabra("hola")
	l.agregarPalabra("hola")
	res = res and l.cantidadDePalabras() == 1	
	printTestResult(res, 6)

###############################################################################################

def test7():
	# chequeo borrar una palabra de un Ayudante vacio
	res = True
	l = Ayudante()
	l.eliminarPalabra("parola")
	res = res and l.cantidadDePalabras() == 0	
	printTestResult(res, 7)

###############################################################################################

def test8():
	# chequeo de palabras jugables
	res = True
	l = Ayudante()
	
	# Inicialmente para cualquier conjunto devuelve nada
	res = res and len(l.palabrasPosibles("hola")) == 0

	words = ["loca", "calo", "ocal", "laca", "cala"]
	for w in words:
		l.agregarPalabra(w)

	s1 = l.palabrasPosibles("loca")
	res = res and s1 == set(["loca", "calo", "ocal"])
	s2 = l.palabrasPosibles("acol")
	res = res and s1 == s2
	s3 = l.palabrasPosibles("aalc")
	res = res and s3 == set(["laca", "cala"])
	printTestResult(res, 8)


# SE EJECUTAN TODOS LOS TESTS
test1()
test2()
test3()
test4()
test5()
test6()
test7()
test8()

