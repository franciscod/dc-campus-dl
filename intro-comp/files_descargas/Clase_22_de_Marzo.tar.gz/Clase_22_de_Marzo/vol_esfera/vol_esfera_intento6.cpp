#include <iostream>
#include <math.h> //Para usar la función pow

using namespace std;

int main (){

  double radio;

  cout << "Por favor, introduzca el radio de su esfera: " << endl;

  cin >> radio;

  if ( radio < 0 ){
    cout << "Me estàs tomando el pelo!" << endl;
    return 1;
  }
  
  const double pi = 3.141592;

  double radio_al_cubo = pow(radio,3);

  double volumen = (4.0/3.0)*pi*(radio_al_cubo);

  cout << "Su esfera de radio " << radio << " tiene volumen: " << volumen << endl;

  return 0;

}

//Este último intento le pide al usuario que introduzca el radio de la esfera.
