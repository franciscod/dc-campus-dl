#include <iostream>
#include <math.h> //Para usar la función pow
#include <array> //Para usar arrays, duh

using namespace std;

//Ahora tenemos 4 frutas en un bol, y queremos saber cuál es el volumen ocupado por todas ellas.

int main (){

  array <double,4> radios;

  cout << "Por favor, introduzca el radio de la manzana: " << endl;
  cin >> radios[0];

  cout << "Por favor, introduzca el radio de la uva: " << endl;
  cin >> radios[1];

  cout << "Por favor, introduzca el radio de la naranja: " << endl;
  cin >> radios[2];

  cout << "Por favor, introduzca el radio del melón: " << endl;
  cin >> radios[3];
  
  const double pi = 3.141592;

  double volumen_total = 0;

  int i = 0; //un contador
  
  while ( i < 4 ){

    double volumen_de_la_iesima_fruta = (4.0/3.0) * pi * pow(radios[i],3);
    
    volumen_total = volumen_total + volumen_de_la_iesima_fruta; 

    i = i+1;
    
  }
  
  cout << "El volumen total de frutas en su bol es: " << volumen_total << endl;

  return 0;

}
