#include <iostream>

using namespace std;

int main ( int argc, char* argv[] ){

  int radio = 3;

  int volumen = 4/3 * pi * radio^3;

  cout << "El volumen de la esfera de radio 3 es: " << volumen << endl;

  return 0;

}
