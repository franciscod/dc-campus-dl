#include <iostream>

using namespace std;

int main (){

  int radio = 3;

  const double pi = 3.141592;

  double volumen = (4/3)*pi*(radio^3);

  cout << "El volumen de una esfera de radio 3 es: " << volumen << endl;

  return 0;

}

//Problema: ^ no es la exponenciación de números.
