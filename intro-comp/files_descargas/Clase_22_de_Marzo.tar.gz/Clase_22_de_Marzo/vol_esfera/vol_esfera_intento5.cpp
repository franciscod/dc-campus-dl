#include <iostream>
#include <math.h> //Para usar la función pow

using namespace std;

int main ( int argc, char* argv[] ){

  int radio = 3;

  const double pi = 3.141592;

  double radio_al_cubo = pow(radio,3);

  double volumen = (4.0/3.0)*pi*(radio_al_cubo);

  cout << "El volumen de una esfera de radio 3 es: " << volumen << endl;

  return 0;

}

//Ahora sí nos da lo que queremos, pero se puede mejorar. Por ejemplo, el programa no nos deja cambiar el radio.
