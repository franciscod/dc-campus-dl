#include <iostream>

using namespace std;

int main ( int argc, char * argv[]){

	int radio = 3;
	
	cout << "El volumen de una esfera de radio 3 es: " << "4/3 * radio * pi^3" << endl;

	return 0;

}
