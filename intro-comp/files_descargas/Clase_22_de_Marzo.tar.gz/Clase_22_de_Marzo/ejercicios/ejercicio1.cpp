/* Queremos un programa que siempre le gane al usuario jugando piedra, papel o tijera.

Este código tiene varios errores y no compila. Encontrá los errores y arreglalos. 

Bonus: cambiá el código para que la computadora siempre pierda contra el usuario */

int main(){

  cout << "Elegí roca, papel o tijera (R/P/T)" << endl;

  char a

  a = cin.get(); //agarra el primer caracter de lo que el usuario escriba--esto no lo vimos pero está bien

  if ( a == R )
    cout << P << endl;
  else if ( a = P )
    cout << T << endl;
  else if ( a = T )
    cout << R << endl;
  else
    cout << "Me lastima que no te estés tomando esto en serio." << endl;

  cout << "¡Perdiste!" << endl;

  return 0;
}

  
  
