/* Queremos un programa que nos diga si un número introducido por el usuario pertenece a un arreglo dado. Este código tiene varios errores. Encontralos y arreglalos. */

#include <iostream>

using namespace std;

main () {

  array <int,5> mi_arreglo =  {1,3,7,12,18,26,35,45,56,69};

  int a;

  cout << "Por favor, escribí un número" << endl;

  cin >> a;

  bool pertenece = false;

  int i = 0;
  
  while ( i<10 ){
    
    if ( mi_arreglo[i] == a )
      {pertenece = true;}

    i = i+1;
    
  }

  if ( pertenece )
    cout << "Tu número forma parte del arreglo" << endl;
  else
    cout << "¡No queremos a los de tu tipo!" << endl;

  return 0

}

  
