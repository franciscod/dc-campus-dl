from list_algorithms import presentar
import random
grupo= 'grupo_12'

@presentar
def insertion_sort(a):
    return a

@presentar
def selection_sort(a):
    return a
