from list_algorithms import presentar
import random
grupo= 'grupo_2'

@presentar
def selection_sort(a):
    return a

@presentar
def bubble_sort(a):
    return a
