from list_algorithms import presentar
import random
grupo= 'grupo_10'

@presentar
def bubble_sort(a):
    return a

@presentar
def insertion_sort(a):
    return a
