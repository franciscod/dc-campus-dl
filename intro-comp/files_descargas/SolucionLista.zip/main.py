from TIPO_LISTA_EJ2 import Lista

# usos del tipo lista
l = Lista()
l.agregar(3)
l.agregar(5)
l.agregar(8)
l.agregar(8)
l.agregar(1)
print l, l.longitud()
l.reemplazar(8, 15)
print l, l.longitud()
print l.iesimo(0), l.iesimo(1), l.iesimo(2), l.iesimo(3), l.iesimo(4)
l.borrar(15)
print l, l.longitud(), l.estaVacia()
l.agregar(6)
print l, l.longitud(), l.estaVacia()
l.borrar(6)
print l, l.longitud(), l.estaVacia()
l.agregar(99)
print l, l.longitud(), l.estaVacia()
l.vaciar()
print l, l.longitud(), l.estaVacia()

