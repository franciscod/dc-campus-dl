# Clase _Nodo
# Estructura de representacion: Nodo=<_valor:Z, _siguiente:Ref(_Nodo)>
class _Nodo:
	def __init__(self, x):
		self._valor = x
		self._siguiente = None

# Clase Lista
# Estructura de representacion:  Lista=<_primero:ref(_Nodo)>
# Invariante de representacion: 
#		(i) _primero apunta al primer elemento de la lista; 
#		(ii) los nodos alcanzables desde _primero no forman ciclos
class Lista:
	# crea una lista vacia en O(1)
	def __init__(self):
		self._primero = None
		
	# agrega x al final de la lista en O(n)
	def agregar(self, x):
		n = _Nodo(x)
		if self._primero == None:
			self._primero = n
		else:
			aux = self._primero
			while aux._siguiente != None:
				aux = aux._siguiente
			aux._siguiente = n
	
	# borra todas las ocurrencias de x en O(n) 
	def borrar(self, x):
		if self._primero != None:
			if self._primero._valor == x:
				self._primero = self._primero._siguiente
				self.borrar(x)
			else:
				anterior = self._primero
				corriente = self._primero._siguiente
				while corriente != None:
					if corriente._valor == x:
						anterior._siguiente = corriente._siguiente
					else:
						anterior = corriente
					corriente = corriente._siguiente
	
	# reemplaza todas las ocurrencias de x por y en O(n)
	def reemplazar(self, x, y):
		n = self._primero
		while n != None:
			if n._valor == x:
				n._valor = y
			n = n._siguiente
			
	# devuelve la longitud de la lista en O(n)
	def longitud(self):
		ret = 0
		n = self._primero
		while n != None:
			ret = ret+1
			n = n._siguiente
		return ret
	
	# devuelve el i-esimo elemento en O(n). pre: 0<i<longitud(self)
	def iesimo(self, i):
		j = 0
		n = self._primero
		while j < i:
			j = j+1
			n = n._siguiente
		return n._valor
	
	# devuelve true sii la lista esta vacia en O(1)
	def estaVacia(self):
		return self._primero == None
		
	# vacia la lista en O(1)
	def vaciar(self):
		self._primero = None

	# para imprimir la lista en O(n)
	def __str__(self):
		ret = "["
		if self._primero != None:
			ret = ret+str(self._primero._valor)
			n = self._primero._siguiente
			while n != None:
				ret = ret+","+str(n._valor)
				n = n._siguiente
		ret = ret+"]"
		return ret
	

