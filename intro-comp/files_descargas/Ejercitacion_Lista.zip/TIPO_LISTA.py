# Clase _Nodo
# Estructura de representacion: _Nodo=<_valor:Z, _siguiente:Ref(_Nodo)>
class _Nodo:
	def __init__(self, x):
		self._valor = x
		self._siguiente = None

# Clase Lista
# Estructura de representacion:  Lista=<_primero:ref(Nodo)>
# Invariante de representacion: 
#		(i) _primero apunta al primer elemento de la lista; 
#		(ii) los nodos alcanzables desde _primero no forman ciclos
class Lista:
	# crea una lista vacia en O(1)
	def __init__(self):
		self._primero = None
		
	# agrega x al final de la lista O(n)
	def agregar(self, x):
		pass 
	
	# borra todas las ocurrencias de x en O(n)
	def borrar(self, x):
		pass
	
	# reemplaza todas las ocurrencias de x por y en O(n)
	def reemplazar(self, x, y):
		pass
			
	# devuelve la longitud de la lista en (n)
	def longitud(self):
		pass
	
	# devuelve el i-esimo elemento. pre: 0<i<longitud(self) en O(n)
	def iesimo(self, i):
		pass
	
	# devuelve true sii la lista esta vacia en O(1)
	def estaVacia(self):
		pass
		
	# vacia la lista en O(1)
	def vaciar(self):
		pass

	# para imprimir la lista en (n)
	def __str__(self):
		return "metodo no implementado"
	

