#include <iostream>

using namespace std;

int main (int argc, char** argv) {

    string operacion = argv[1];
    int n1 = atoi(argv[2]);
    int n2 = atoi(argv[3]);

    if (operacion == "sumar")
        cout << "la suma de " << n1 << " y " << n2 << " es: " << n1 + n2 << endl;
    else {
        if (operacion == "restar")
            cout << "la resta de " << n1 << " y " << n2 << " es: " << n1 - n2 << endl;
        else
            cout << "que quisiste poner??" << endl;
    }
    return 0;
}