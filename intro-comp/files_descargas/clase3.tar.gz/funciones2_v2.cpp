#include <iostream>

using namespace std;

void saludar() {
    cout << "Hola, mundo!" << endl;
}

int main() {

    saludar();

    return 0;
}


