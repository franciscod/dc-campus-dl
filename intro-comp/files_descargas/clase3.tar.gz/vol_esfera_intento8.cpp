#include <iostream>
#include <math.h> //Para usar la función pow
#include <array> //Para usar arrays, duh

using namespace std;

//Ahora tenemos 4 frutas en un bol, y queremos saber cuál es el volumen ocupado por todas ellas.


double calcularVolumen(double radio) {
  const double pi = 3.141592;
  return (4.0/3.0) * pi * pow(radio,3);
}

double calcularVolumenTotal(array<double, 4> radios) {

  double volumen_total = 0;

  int i = 0; //un contador

  while ( i < 4 ){

    volumen_total = volumen_total + calcularVolumen(radios[i]);

    i = i+1;

  }
  return volumen_total;
}

int main (){

  array <double,4> radios;

  cout << "Por favor, introduzca el radio de la manzana: " << endl;
  cin >> radios[0];

  cout << "Por favor, introduzca el radio de la uva: " << endl;
  cin >> radios[1];

  cout << "Por favor, introduzca el radio de la naranja: " << endl;
  cin >> radios[2];

  cout << "Por favor, introduzca el radio del melón: " << endl;
  cin >> radios[3];

  cout << "El volumen total de frutas en su bol es: " << calcularVolumenTotal(radios) << endl;

  return 0;

}
