#include <iostream>

using namespace std;

bool esPar(int n) {
    return n % 2 == 0;
}

void imprimirParidad(int n) {
    if (esPar(n)) {
        cout << "Ingresaste un número par!" << endl;
    } else {
        cout << "Ingresaste un número impar!" << endl;
    }
}

int main() {
    cout << "Ingrese un numero entero: " << endl;
    int n;
    cin >> n;

    imprimirParidad(n);

    return 0;
}
