class _Nodo:
    def __init__(self,x):
        self._valor = x
        self._i = None
        self._d = None
        
class Binarbol:

    def __init__(self, r, binIzq=None, binDer=None):
        n = _Nodo(r)
        n._i = binIzq
        n._d = binDer

        self._raiz = n

    def raiz(self):
        #devuelve el valor de la raíz del árbol
        return self._raiz._valor

    def hayIzq(self):
        #devuelve true sii el árbol tiene subárbol izquierdo
        if self._raiz._i != None:
            return True
        else:
            return False

    def hayDer(self):
        #devuelve true sii el árbol tiene subárbol derecho
        if self._raiz._d != None:
            return True
        else:
            return False

    def izq(self):
        #devuelve el subárbol izquierdo, precondición: hayIzq(self)
        return self._raiz._i

    def der(self):
        #devuelve el subárbol derecho, precondición: hayDer(self)
        return self._raiz._d
        
    
